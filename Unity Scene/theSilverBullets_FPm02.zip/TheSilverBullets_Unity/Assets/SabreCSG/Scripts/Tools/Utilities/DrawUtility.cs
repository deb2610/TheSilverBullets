﻿#if UNITY_EDITOR || RUNTIME_CSG
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Sabresaurus.SabreCSG
{
	/// <summary>
	/// Provides helper methods for dealing with brush drawing
	/// </summary>
	public static class DrawUtility
	{
		
	}
}
#endif